This is an EasyCAT custom project.

This means that the variables exchanged with the EterCAT master have been
customized using the Easy Configurator, a software tool freely downloadable  
from the AB&T website http://www.bausano.net

The Easy Configurator tool creates 3 files:

".h" file that must be included in the user application project.
".bin" file that must be loaded in the EasyCAT EEPROM.
".xml" file that could be used by the EtherCAT master.

for more information please download the Easy Configurator user manual from the
AB&T website http://www.bausano.net

